import { c as createRoot, j as jsxRuntimeExports, r as reactExports } from "./assets/client-DKdm6VkQ.js";
const Options = () => {
  const [email, setEmail] = reactExports.useState("");
  const [password, setPassword] = reactExports.useState("");
  const [token, setToken] = reactExports.useState(null);
  async function login() {
    const res = await fetch("http://localhost:8080/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, password }) });
    if (res.ok) {
      const data = await res.json();
      setToken(data.token);
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { fontFamily: "sans-serif" }, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { children: "Groupem Login" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("input", { placeholder: "Email", value: email, onChange: (e) => setEmail(e.target.value) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("input", { placeholder: "Password", type: "password", value: password, onChange: (e) => setPassword(e.target.value) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: login, children: "Login" }),
    token && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: "Logged in" })
  ] });
};
createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(Options, {}));
