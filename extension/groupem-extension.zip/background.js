import { b as browser } from "./assets/browser-polyfill-DYkDHo0p.js";
browser.runtime.onInstalled.addListener(() => {
  console.log("Groupem background ready");
  try {
    chrome.management.getSelf((self) => {
      if (self && self.id) {
        chrome.storage.local.set({ __GROUPEM_EXT_ID: self.id });
      }
    });
  } catch {
  }
});
browser.tabs.onCreated.addListener((tab) => {
  console.log("Tab created", tab == null ? void 0 : tab.id);
});
browser.runtime.onMessage.addListener((msg) => {
  if ((msg == null ? void 0 : msg.type) === "groupem-activate") {
    console.log("Activator ping received");
    try {
      chrome.management.getSelf((self) => {
        if (self && self.id) {
          chrome.storage.local.set({ __GROUPEM_EXT_ID: self.id });
        }
      });
    } catch {
    }
  }
});
