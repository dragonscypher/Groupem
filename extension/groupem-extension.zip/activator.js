var _a, _b;
try {
  (_b = (_a = chrome.runtime) == null ? void 0 : _a.sendMessage) == null ? void 0 : _b.call(_a, { type: "groupem-activate" });
} catch {
}
