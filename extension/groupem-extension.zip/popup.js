import { c as createRoot, j as jsxRuntimeExports, r as reactExports } from "./assets/client-DKdm6VkQ.js";
import { b as browser } from "./assets/browser-polyfill-DYkDHo0p.js";
const scriptRel = "modulepreload";
const assetsURL = function(dep) {
  return "/" + dep;
};
const seen = {};
const __vitePreload = function preload(baseModule, deps, importerUrl) {
  let promise = Promise.resolve();
  if (deps && deps.length > 0) {
    document.getElementsByTagName("link");
    const cspNonceMeta = document.querySelector(
      "meta[property=csp-nonce]"
    );
    const cspNonce = (cspNonceMeta == null ? void 0 : cspNonceMeta.nonce) || (cspNonceMeta == null ? void 0 : cspNonceMeta.getAttribute("nonce"));
    promise = Promise.allSettled(
      deps.map((dep) => {
        dep = assetsURL(dep);
        if (dep in seen) return;
        seen[dep] = true;
        const isCss = dep.endsWith(".css");
        const cssSelector = isCss ? '[rel="stylesheet"]' : "";
        if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
          return;
        }
        const link = document.createElement("link");
        link.rel = isCss ? "stylesheet" : scriptRel;
        if (!isCss) {
          link.as = "script";
        }
        link.crossOrigin = "";
        link.href = dep;
        if (cspNonce) {
          link.setAttribute("nonce", cspNonce);
        }
        document.head.appendChild(link);
        if (isCss) {
          return new Promise((res, rej) => {
            link.addEventListener("load", res);
            link.addEventListener(
              "error",
              () => rej(new Error(`Unable to preload CSS for ${dep}`))
            );
          });
        }
      })
    );
  }
  function handlePreloadError(err) {
    const e = new Event("vite:preloadError", {
      cancelable: true
    });
    e.payload = err;
    window.dispatchEvent(e);
    if (!e.defaultPrevented) {
      throw err;
    }
  }
  return promise.then((res) => {
    for (const item of res || []) {
      if (item.status !== "rejected") continue;
      handlePreloadError(item.reason);
    }
    return baseModule().catch(handlePreloadError);
  });
};
async function embedTexts(texts) {
  try {
    const ort = await __vitePreload(() => import("./assets/ort.bundle.min-QT1Tf6E1.js"), true ? [] : void 0);
    if (ort && ort.InferenceSession) {
      throw new Error("no-local-model");
    }
  } catch {
  }
  try {
    const resp = await fetch("http://localhost:8000/embed", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text: texts }) });
    if (resp.ok) {
      const data = await resp.json();
      if (Array.isArray(data.vectors)) return data.vectors;
    }
  } catch {
  }
  try {
    const token = await getToken();
    if (token) {
      const objects = texts.map((t, i) => ({ id: "loc-" + i, text: t }));
      await fetch("http://localhost:8080/tools/embeddings.index", { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify({ objects }) });
      const vectors = [];
      for (const t of texts) {
        const r = await fetch("http://localhost:8080/tools/embeddings.query", { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify({ text: t, topK: texts.length }) });
        if (r.ok) {
          const scored = await r.json();
          const map = {};
          for (const s of scored) map[s.objectId] = s.score;
          vectors.push(objects.map((o) => map[o.id] || 0));
        } else {
          vectors.push(new Array(texts.length).fill(0));
        }
      }
      return vectors;
    }
  } catch {
  }
  return texts.map(() => []);
}
async function fetchTabs() {
  const tabs = await browser.tabs.query({ currentWindow: true });
  return tabs.map((t) => ({ id: t.id || 0, title: t.title || "", url: t.url || "" }));
}
function clusterTabs(tabs) {
  const map = /* @__PURE__ */ new Map();
  for (const tab of tabs) {
    try {
      const u = new URL(tab.url);
      map.set(tab.url, u.hostname.split(".").slice(-2).join("."));
    } catch {
      map.set(tab.url, "other");
    }
  }
  return tabs.map((t) => ({ ...t, group: map.get(t.url) }));
}
async function getToken() {
  const stored = await browser.storage.local.get("token");
  const value = stored.token;
  return typeof value === "string" ? value : null;
}
async function listSessions() {
  const token = await getToken();
  if (!token) return [];
  const res = await fetch("http://localhost:8080/tools/tabs.listGroups", { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: "{}" });
  if (!res.ok) return [];
  const data = await res.json();
  return data.items || [];
}
async function saveSession(tabs) {
  const token = await getToken();
  if (!token) return null;
  const groupsMap = {};
  for (const t of tabs) {
    const g = t.group || "ungrouped";
    groupsMap[g] = groupsMap[g] || [];
    groupsMap[g].push(String(t.id));
  }
  const groups = Object.entries(groupsMap).map(([label, tabIds]) => ({ id: label + Date.now(), label, category: label, tabIds }));
  const body = { session: { id: crypto.randomUUID(), createdAt: (/* @__PURE__ */ new Date()).toISOString(), device: "extension", groups } };
  const res = await fetch("http://localhost:8080/tools/tabs.saveGroups", { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify(body) });
  if (res.ok) {
    const d = await res.json();
    return d.id;
  }
  return null;
}
async function loadSession(id) {
  const token = await getToken();
  if (!token) return null;
  const res = await fetch("http://localhost:8080/tools/tabs.loadGroups", { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify({ id }) });
  if (!res.ok) return null;
  return await res.json();
}
const App = () => {
  const [tabs, setTabs] = reactExports.useState([]);
  const [sessions, setSessions] = reactExports.useState([]);
  const [saving, setSaving] = reactExports.useState(false);
  const [loading, setLoading] = reactExports.useState(true);
  const [error, setError] = reactExports.useState(null);
  const [embeddingStatus, setEmbeddingStatus] = reactExports.useState("");
  const [token, setToken] = reactExports.useState(null);
  const [email, setEmail] = reactExports.useState("");
  const [password, setPassword] = reactExports.useState("");
  const [totp, setTotp] = reactExports.useState("");
  const [authError, setAuthError] = reactExports.useState(null);
  const [registerMode, setRegisterMode] = reactExports.useState(false);
  const [phone, setPhone] = reactExports.useState("");
  const [provisionedSecret, setProvisionedSecret] = reactExports.useState(null);
  reactExports.useEffect(() => {
    (async () => {
      try {
        const stored = await browser.storage.local.get(["token", "userEmail"]);
        const existing = stored.token || null;
        const storedEmail = stored.userEmail || "";
        setToken(existing);
        if (storedEmail) setEmail(storedEmail);
        const t = await fetchTabs();
        setTabs(clusterTabs(t));
        if (existing) setSessions(await listSessions());
      } catch (e) {
        setError("Failed to load tabs");
      } finally {
        setLoading(false);
      }
    })();
  }, []);
  async function handleSave() {
    setSaving(true);
    const id = await saveSession(tabs);
    setSaving(false);
    if (id) setSessions(await listSessions());
  }
  async function handleRestore(id) {
    const session = await loadSession(id);
    if (session) {
      console.log("Restored session", session.id, session.groups.length);
    }
  }
  async function handleEmbeddingsTest() {
    var _a;
    setEmbeddingStatus("Embedding...");
    const texts = tabs.slice(0, 5).map((t) => t.title || t.url).filter(Boolean);
    const vectors = await embedTexts(texts);
    setEmbeddingStatus(`Generated ${vectors.length} vectors (len=${((_a = vectors[0]) == null ? void 0 : _a.length) || 0})`);
  }
  async function handleLogin(e) {
    e.preventDefault();
    setAuthError(null);
    try {
      const res = await fetch("http://localhost:8080/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, password, totp: totp || void 0 }) });
      if (!res.ok) {
        const data2 = await res.json().catch(() => ({}));
        setAuthError(data2.error || "login-failed");
        return;
      }
      const data = await res.json();
      await browser.storage.local.set({ token: data.token, userEmail: email });
      setToken(data.token);
      setSessions(await listSessions());
    } catch {
      setAuthError("network");
    }
  }
  async function handleRegister(e) {
    e.preventDefault();
    setAuthError(null);
    setProvisionedSecret(null);
    try {
      const body = { email, password };
      if (phone) body.phone = phone;
      body.autoTotp = true;
      const res = await fetch("http://localhost:8080/auth/register", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setAuthError(data.error || "register-failed");
        return;
      }
      if (data.totpSecret) setProvisionedSecret(data.totpSecret);
      setRegisterMode(false);
    } catch {
      setAuthError("network");
    }
  }
  async function handleLogout() {
    await browser.storage.local.remove("token");
    setToken(null);
    setSessions([]);
  }
  if (loading) return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { fontFamily: "sans-serif", width: 360 }, children: "Loading..." });
  if (error) return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { fontFamily: "sans-serif", width: 360, color: "red" }, children: error });
  if (!token) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { fontFamily: "sans-serif", width: 360 }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { children: registerMode ? "Register" : "Groupem Login" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: registerMode ? handleRegister : handleLogin, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { marginBottom: 6 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx("input", { style: { width: "100%" }, placeholder: "Email", value: email, onChange: (e) => setEmail(e.target.value) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { marginBottom: 6 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx("input", { style: { width: "100%" }, placeholder: "Password", type: "password", value: password, onChange: (e) => setPassword(e.target.value) }) }),
        registerMode && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { marginBottom: 6 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx("input", { style: { width: "100%" }, placeholder: "Phone (optional)", value: phone, onChange: (e) => setPhone(e.target.value) }) }),
        !registerMode && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { marginBottom: 6 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx("input", { style: { width: "100%" }, placeholder: "TOTP (if enrolled)", value: totp, onChange: (e) => setTotp(e.target.value) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "submit", disabled: !email || !password, children: registerMode ? "Register" : "Login" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", style: { marginLeft: 8 }, onClick: () => {
          setRegisterMode(!registerMode);
          setAuthError(null);
        }, children: registerMode ? "Have account?" : "Create account" }),
        authError && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { color: "red", fontSize: 12, marginTop: 4 }, children: authError }),
        provisionedSecret && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { fontSize: 11, marginTop: 6 }, children: [
          "TOTP Secret: ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("code", { children: provisionedSecret })
        ] })
      ] })
    ] });
  }
  const groupLabels = Array.from(new Set(tabs.map((t) => t.group || "other")));
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { fontFamily: "sans-serif", width: 360 }, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { children: "Groupem" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { style: { fontSize: 12, opacity: 0.7 }, children: email || "Logged in" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: handleLogout, style: { fontSize: 11 }, children: "Logout" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: handleSave, disabled: saving, children: saving ? "Saving..." : "Save Session" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: handleEmbeddingsTest, style: { marginLeft: 8 }, children: "Test Embeddings" }),
    embeddingStatus && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { fontSize: 11, marginTop: 4 }, children: embeddingStatus }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { children: "Current Groups" }),
    groupLabels.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: "No tabs" }),
    groupLabels.map((g) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: g }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { children: tabs.filter((t) => (t.group || "other") === g).map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: t.title }, t.id)) })
    ] }, g)),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { children: "Saved Sessions" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { children: sessions.map((s) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => handleRestore(s.id), children: "Restore" }),
      " ",
      new Date(s.createdAt).toLocaleTimeString(),
      " (",
      s.groups.length,
      " groups)"
    ] }, s.id)) })
  ] });
};
createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(App, {}));
